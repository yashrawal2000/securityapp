to run the tool --> python gui.py   
