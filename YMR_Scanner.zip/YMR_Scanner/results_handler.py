import tkinter.messagebox as messagebox
from tkinter import filedialog

def save_results():
    file_path = filedialog.asksaveasfilename(defaultextension=".txt", 
                                               filetypes=[("Text files", "*.txt"),
                                                          ("PDF files", "*.pdf"),
                                                          ("Excel files", "*.xlsx")])
    if file_path:
        # Logic to save results to the selected file path
        messagebox.showinfo("Save Results", f"Results saved to {file_path}")
