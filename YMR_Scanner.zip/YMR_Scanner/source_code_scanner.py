import os
import re

def scan_source_code(directory):
    """
    Scans the specified directory for source code files for common vulnerabilities.

    Parameters:
    directory (str): The path to the directory containing source code files.

    Returns:
    dict: A dictionary with the scan results.
    """
    results = {
        'total_files_scanned': 0,
        'hard_coded_secrets_found': [],
        'insecure_patterns_found': [],
    }

    # Loop through each file in the directory
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(('.py', '.java', '.js', '.php')):  # Add file extensions as needed
                results['total_files_scanned'] += 1
                file_path = os.path.join(root, file)
                with open(file_path, 'r', errors='ignore') as f:
                    content = f.read()
                    if check_hard_coded_secrets(content):
                        results['hard_coded_secrets_found'].append(file_path)
                    if check_insecure_patterns(content):
                        results['insecure_patterns_found'].append(file_path)

    return results

def check_hard_coded_secrets(content):
    """
    Checks for hard-coded secrets in the provided content.

    Parameters:
    content (str): The source code content.

    Returns:
    bool: True if hard-coded secrets are found, otherwise False.
    """
    # Regex to find common patterns for hard-coded secrets
    secret_patterns = [
        r'(?i)(password|secret|key|token)\s*=\s*["\'].*?["\']',  # Common secret assignments
        r'(?i)(username|api_key)\s*=\s*["\'].*?["\']',
        r'(?i)(\d{16}|\w{32,})',  # Generic pattern for sensitive values
    ]

    for pattern in secret_patterns:
        if re.search(pattern, content):
            return True
    return False

def check_insecure_patterns(content):
    """
    Checks for insecure coding patterns in the provided content.

    Parameters:
    content (str): The source code content.

    Returns:
    bool: True if insecure patterns are found, otherwise False.
    """
    # Regex to find common insecure coding patterns
    insecure_patterns = [
        r'(?i)(eval|exec|system|os\.system)',  # Use of dangerous functions
        r'(?i)(open\(\s*["\'].*?["\']\s*,\s*["\']w["\']\s*)',  # Writing to files without checks
        r'(?i)(import\s+os)',  # Insecure imports
    ]

    for pattern in insecure_patterns:
        if re.search(pattern, content):
            return True
    return False

def start_source_code_scan(directory):
    """
    Starts the source code scanning process for the specified directory.

    Parameters:
    directory (str): The path to the directory containing source code files.

    Returns:
    dict: A dictionary with the scan results.
    """
    print(f"Scanning source code in directory: {directory}...")
    results = scan_source_code(directory)
    return results

def format_source_code_scan_results(results):
    """
    Formats the results of the source code scan for display.

    Parameters:
    results (dict): The dictionary of scan results.

    Returns:
    str: A formatted string of the results.
    """
    output = f"Source Code Scan Results:\n"
    output += f"Total Files Scanned: {results['total_files_scanned']}\n"
    output += f"Hard-Coded Secrets Found in Files:\n"
    for file in results['hard_coded_secrets_found']:
        output += f" - {file}\n"
    output += f"Insecure Patterns Found in Files:\n"
    for file in results['insecure_patterns_found']:
        output += f" - {file}\n"
    return output



# scr_scanner.py

def start_scr_scan(file_path):
    try:
        # Simulate the source code scan for now
        # In a real scenario, you can add scanning logic here
        result = f"Scanning source code in {file_path}...\nNo vulnerabilities found."
        return result
    except Exception as e:
        return f"Error scanning source code: {str(e)}"

