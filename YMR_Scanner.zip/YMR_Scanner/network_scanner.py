import scapy.all as scapy
import socket
import threading

def scan_network(ip_range):
    """
    Scans the specified IP range for active hosts and identifies open ports.

    Parameters:
    ip_range (str): The IP range to scan (e.g., '192.168.1.0/24').

    Returns:
    dict: A dictionary with IP addresses as keys and a list of open ports as values.
    """
    active_hosts = {}
    # Discover active hosts in the network
    arp_request = scapy.ARP(pdst=ip_range)
    broadcast = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
    arp_request_broadcast = broadcast / arp_request
    answered_list = scapy.srp(arp_request_broadcast, timeout=1, verbose=False)[0]

    # Collecting active hosts
    for element in answered_list:
        ip = element[1].psrc
        active_hosts[ip] = []

    # Scan each active host for open ports
    for ip in active_hosts.keys():
        active_hosts[ip] = scan_ports(ip)

    return active_hosts

def scan_ports(ip):
    """
    Scans for open ports on the specified IP address.

    Parameters:
    ip (str): The IP address to scan.

    Returns:
    list: A list of open ports on the specified IP address.
    """
    open_ports = []
    # Use a simple range of ports (1-1024)
    for port in range(1, 1025):
        result = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result.settimeout(0.5)  # Set a timeout for the connection attempt
        try:
            result.connect((ip, port))
            open_ports.append(port)
        except (socket.timeout, ConnectionRefusedError):
            pass
        finally:
            result.close()
    return open_ports

def start_network_scan(ip_range):
    """
    Starts the network scanning process for the specified IP range.

    Parameters:
    ip_range (str): The IP range to scan.

    Returns:
    str: A string representation of the scan results.
    """
    print(f"Scanning network: {ip_range}...")
    results = scan_network(ip_range)
    result_str = format_results(results)
    return result_str

def format_results(results):
    """
    Formats the results of the network scan for display.

    Parameters:
    results (dict): The dictionary of scan results.

    Returns:
    str: A formatted string of the results.
    """
    output = ""
    for ip, ports in results.items():
        if ports:
            output += f"Host: {ip}, Open Ports: {', '.join(map(str, ports))}\n"
        else:
            output += f"Host: {ip}, No open ports found.\n"
    return output
