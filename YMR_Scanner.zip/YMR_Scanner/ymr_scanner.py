import tkinter as tk
from tkinter import filedialog, ttk, messagebox
from ai.vulnerability_detection import VulnerabilityDetector
from ai.network_anomaly_detection import NetworkAnomalyDetector
from ai.source_code_scan import CodeScanner
from web_scanner import start_web_scan

class YMRScanner:
    def __init__(self):
        # Initialize AI models
        self.vuln_detector = VulnerabilityDetector()
        self.anomaly_detector = NetworkAnomalyDetector()
        self.code_scanner = CodeScanner()

        # Setup GUI
        self.root = tk.Tk()
        self.root.title("YMR Scanner v1.2 - AI Enhanced")
        self.root.geometry("800x600")

        self.setup_gui()

    def setup_gui(self):
        # Tabs
        self.tab_control = ttk.Notebook(self.root)
        self.dashboard_tab = ttk.Frame(self.tab_control)
        self.source_code_tab = ttk.Frame(self.tab_control)
        self.network_tab = ttk.Frame(self.tab_control)
        self.mobile_tab = ttk.Frame(self.tab_control)

        self.tab_control.add(self.dashboard_tab, text="Dashboard")
        self.tab_control.add(self.source_code_tab, text="Source Code Scan")
        self.tab_control.add(self.network_tab, text="Network Scan")
        self.tab_control.add(self.mobile_tab, text="Mobile Scan")
        self.tab_control.pack(expand=1, fill="both")

        # Input Field
        self.url_label = tk.Label(self.dashboard_tab, text="Enter URL:")
        self.url_label.pack(pady=10)
        self.url_entry = tk.Entry(self.dashboard_tab, width=50)
        self.url_entry.pack(pady=5)

        # Progress Bar
        self.progress_bar = ttk.Progressbar(self.dashboard_tab, orient="horizontal", length=400, mode="determinate")
        self.progress_bar.pack(pady=20)

        # Scan Buttons
        self.start_scan_button = tk.Button(self.dashboard_tab, text="Start Web Scan", command=self.start_web_scan)
        self.start_scan_button.pack(pady=5)

        self.source_code_button = tk.Button(self.source_code_tab, text="Select Folder and Scan", command=self.start_source_code_scan)
        self.source_code_button.pack(pady=10)

        # Network Scan (Placeholder)
        self.network_scan_button = tk.Button(self.network_tab, text="Start Network Scan", command=self.start_network_scan)
        self.network_scan_button.pack(pady=10)

        # Mobile Scan (Placeholder)
        self.mobile_scan_button = tk.Button(self.mobile_tab, text="Upload Mobile File", command=self.select_mobile_file)
        self.mobile_scan_button.pack(pady=10)

    def update_progress_bar(self, value):
        self.progress_bar['value'] = value
        self.root.update_idletasks()  # Update the progress bar

    # Web Scan with AI-Driven Vulnerability Detection
    def start_web_scan(self):
        url = self.url_entry.get()
        if not url:
            messagebox.showerror("Input Error", "Please enter a URL to scan.")
            return

        self.update_progress_bar(10)
        # Web scan logic (from your web_scanner module)
        scan_results = start_web_scan(url)
        self.update_progress_bar(50)

        # AI-based vulnerability detection
        try:
            vulnerabilities = self.vuln_detector.predict_vulnerabilities(scan_results)
            self.display_scan_results(vulnerabilities)
            self.update_progress_bar(100)
        except Exception as e:
            messagebox.showerror("AI Model Error", str(e))

    # Source Code Scan with AI Integration
    def start_source_code_scan(self):
        folder_selected = filedialog.askdirectory()
        if not folder_selected:
            messagebox.showerror("Input Error", "Please select a folder to scan.")
            return

        self.update_progress_bar(10)

        # Recursive scan through folder and subfolders
        vulnerabilities = []
        for root_dir, sub_dirs, files in os.walk(folder_selected):
            for file in files:
                if file.endswith('.py') or file.endswith('.js'):  # Add file types to scan
                    file_path = os.path.join(root_dir, file)
                    with open(file_path, 'r') as code_file:
                        code_snippet = code_file.read()
                        vuln = self.code_scanner.scan_code(code_snippet)
                        if vuln == 1:  # 1 means vulnerable
                            vulnerabilities.append(f"Vulnerability found in {file_path}")

        self.update_progress_bar(50)
        self.display_scan_results(vulnerabilities)
        self.update_progress_bar(100)

    # Network Scan with AI Anomaly Detection (Placeholder)
    def start_network_scan(self):
        # Placeholder network data for AI testing
        network_data = [
            [0.1, 0.2, 0.3],  # Example network features
            [0.2, 0.1, 0.4]
        ]
        anomalies = self.anomaly_detector.detect_anomalies(network_data)
        self.display_scan_results(anomalies)

    # Mobile File Selection (Placeholder)
    def select_mobile_file(self):
        file_selected = filedialog.askopenfilename(filetypes=[("APK files", "*.apk"), ("IPA files", "*.ipa")])
        if not file_selected:
            messagebox.showerror("Input Error", "Please select a mobile app file to scan.")
            return

        # Add actual mobile scan logic here

    # Display Scan Results
    def display_scan_results(self, results):
        result_window = tk.Toplevel(self.root)
        result_window.title("Scan Results")
        result_window.geometry("600x400")
        
        result_text = tk.Text(result_window)
        result_text.pack(expand=True, fill="both")

        result_text.insert(tk.END, "\n".join(results))

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    app = YMRScanner()
    app.run()
