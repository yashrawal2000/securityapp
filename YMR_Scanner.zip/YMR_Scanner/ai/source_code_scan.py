from transformers import BertTokenizer, BertForSequenceClassification
import torch

class CodeScanner:
    def __init__(self):
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)

    def scan_code(self, code_snippet):
        inputs = self.tokenizer(code_snippet, return_tensors="pt", max_length=512, truncation=True)
        outputs = self.model(**inputs)
        return torch.argmax(outputs.logits, dim=1).item()
